package de.gds;

public class Item {
    private String name;
    private String desc;
    private Boolean takeable;

    public Item(String name, String desc, Boolean takeable) {
        this.name = name;
        this.desc = desc;
        this.takeable = takeable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Boolean getTakeable() {
        return takeable;
    }

    public void setTakeable(Boolean takeable) {
        this.takeable = takeable;
    }
}
