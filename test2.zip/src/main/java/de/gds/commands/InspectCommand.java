package de.gds.commands;

import de.gds.AdventureModel;
import de.gds.Item;
import java.util.List;

public class InspectCommand implements Command {
    @Override
    public String run(AdventureModel model, String[] args) {
        StringBuilder output = new StringBuilder();
        if (args.length == 1) {
            inspectRoom(output, model);
        } else if (args.length == 2) {
            String inspectItem = args[1].trim();
            List<Item> roomItems = model.getAdventurer().getRoom().getItems();
            List<Item> inventory = model.getAdventurer().getInventory();
            boolean found = false;

            for (Item g : roomItems) {
                if (g.getName().equalsIgnoreCase(inspectItem)) {
                    output.append(g.getName() + ": " + g.getDesc());
                    found = true;
                    break;
                }
            }

            if (!found) {
                for (Item g : inventory) {
                    if (g.getName().equalsIgnoreCase(inspectItem)) {
                        output.append(g.getName() + " (in deinem Inventar): " + g.getDesc());
                        found = true;
                        break;
                    }
                }
            }

            if (!found) {
                output.append("Kein Item namens \"" + inspectItem + "\" gefunden.");
            }
        } else {
            output.append("Fehler: INSPECT funktioniert nur mit keinem oder einem Argument!");
        }
        return output.toString();
    }

    private void inspectRoom(StringBuilder string, AdventureModel model) {
        List<Item> items = model.getAdventurer().getRoom().getItems();
            if (items != null && !items.isEmpty()) {
                string.append("Items im Raum: " + items.get(0).getName());
                for (int i = 1; i < items.size(); i++) {
                    string.append(", " + items.get(i).getName());
                }
            } else {
                string.setLength(0);
                string.append("Items im Raum: keine");
            }
    }
    @Override
    public String getName() {
        return "inspect";
    }
}