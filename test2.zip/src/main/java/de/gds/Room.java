package de.gds;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Room {
    private String name;
    private String desc;
    private List<Item> items;
    private Map<String, Boolean> exits = new HashMap<>();
    private Position position;
    
    public Room(String name, String desc, List<Item> items, Map<String, Boolean> exits,
            Position position) {
        this.name = name;
        this.desc = desc;
        this.items = items;
        this.exits = exits;
        this.position = position;
    }

    public Map<String, Boolean> getExits() {
        return exits;
    }

    public void setExits(Map<String, Boolean> exits) {
        this.exits = exits;
    }
    
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public Boolean isExit(String direction) {
        Boolean exists = exits.get(direction);
        return exists != null && exists;
    }
}
